﻿using Windows.ApplicationModel.DataTransfer;

namespace SecurityProject0_client.Models
{
    public class DragDropData
    {
        public DataPackageOperation AcceptedOperation { get; set; }

        public DataPackageView DataView { get; set; }
    }
}
