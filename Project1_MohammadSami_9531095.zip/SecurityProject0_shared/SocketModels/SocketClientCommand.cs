﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SecurityProject0_shared.SocketModels
{
    public abstract class SocketClientCommand : SocketCommand
    {
    }
}
